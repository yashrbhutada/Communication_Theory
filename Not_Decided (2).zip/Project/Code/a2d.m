clc, clearvars, close;
a = 0.5;
m = 30;
length =20;
% a2d
[audio, audio_sampling_rate] = audioread('project.wav');
audio = audio(1:3*audio_sampling_rate);
audio_normalized = int16(audio * 32767);
audio_binary = dec2bin(typecast(audio_normalized(:), 'uint16'), 16);
x1t = audio_binary(:) - '0';
snrdb = 0:1:5;
error = zeros(numel(snrdb),1);
fs = 1e3;
plot(raised_cosine(a,m,length));
% for idx = 1:numel(snrdb)
    % plotter = 1/audio_sampling_rate:1/audio_sampling_rate:length(x1t)/audio_sampling_rate;
%    p